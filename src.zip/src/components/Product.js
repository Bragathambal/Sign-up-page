import React from 'react';

const Product=()=>{
    return(
        <>
        <h1>you are signed up successfully</h1>
       
        </>
    )
}
export default Product